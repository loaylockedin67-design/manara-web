# لعبة أذكار وتاريخ إسلامي

## الرفع على GitHub
1. أنشئ مستودعاً جديداً (Repository) واجعله Public.
2. اضغط Add file ثم Upload files، وارفع الملفات التالية مع الحفاظ على المجلدات:
   - `index.html`
   - `audio/task-complete.mp3`
3. اضغط Commit changes.
4. للتشغيل على الإنترنت: Settings ثم Pages، ثم اختر Branch: main و Folder: / (root) ثم Save.
5. سيظهر رابط اللعبة بالشكل: `https://اسم-المستخدم.github.io/اسم-المستودع/`
